<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>UpWash</title>
    <meta name="theme-color" content="#FF6600">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="shortcut icon" href="{{ asset('img/favicon-old.ico') }}" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/vue@2.7.0"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://js.stripe.com/v3/"></script>
    <script src="{{ asset('js/checkout.js') }}"></script>
    <script src="{{ asset('js/map-js.js') }}"></script>
    
</head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-HKPWBBNHMS"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }

    gtag('js', new Date());

    gtag('config', 'G-HKPWBBNHMS');
</script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   var z = null;m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(90108297, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/90108297" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '436988714373971'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=436988714373971&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
<body>
<div class="preloader">
    <div class="preloader__row">
        <div class="preloader__item"></div>
        <div class="preloader__item"></div>
    </div>
</div>
<div id="app">

    <form action="{{ route('addClient') }}" method="POST" id="add-client">
        @csrf
        <input type="hidden" name="price" v-bind:value="price">
        <div class="desktop">
            <div class="video-wrap">
                <video id="video-tag" autoplay muted loop playsinline class="desktop-video">
                    <source src="{{ asset('media/1370x780.mp4') }}" type="video/mp4"/>
                </video>
                <video id="video-tagz" autoplay muted loop playsinline class="mobile-video">
                    <source src="{{ asset('media/450x780.mp4') }}" type="video/mp4"/>
                </video>
                <img id="img-tag" src="{{ asset('media/450x780.mp4') }}" class="mobile-video mobile-img-tag">
            </div>


            <div class="sections">
                <section class="main">
                    <div class="main-container">
                        <div class="row">
                            <img src="{{ asset('img/logo.png') }}" alt="" class="logo">
                        </div>
                        <div class="row">
                            <h1>Tervetuloa!</h1>
                        </div>
                        <div class="div-button-span">
                            <span class="Lato">Tilaa pesu</span>
                        </div>
                    </div>
                </section>

                <section class="step1" v-bind:class="{ section_active: step >= 1} ">
                    <div class="main-container" v-bind:class="{ main_container_mobile_height: step == 1 }">
                        <div class="step-one-container">

                            <div class="flex" style="display: flex; width: 100%">
                                <div class="step-one-component" v-bind:class='{ inactive: num == ""} '>
                                    <label>
                                        <input type="radio" name="main_type" value="Ulkopesu" v-model="mainType"
                                               v-on:click="go(); rise(1,{{ $prices->step1_1 }})"/>
                                        <img src="{{ asset('img/img1.png') }}">
                                    </label>
                                    <b class="Lato">Ulkopesu</b>
                                </div>
                                <div class="step-one-component" v-bind:class='{ inactive: num == ""} '>
                                    <label>
                                        <input type="radio" name="main_type" value="Sisäpesu" v-model="mainType"
                                               v-on:click="go(); rise(1,{{ $prices->step1_2 }})"/>
                                        <img src="{{ asset('img/img2.png') }}">
                                    </label>
                                    <b class="Lato">Sisäpesu</b>
                                </div>
                            </div>
                            <div class="step-one-third" v-bind:class='{ inactive: num == ""} '>
                                <label>
                                    <input type="radio" name="main_type" value="Molemmat" v-model="mainType"
                                           v-on:click="go(); rise(1,{{ $prices->step1_3 }})"/>
                                    <img src="{{ asset('img/variant3.png') }}">
                                </label>
                                <b class="Lato">Molemmat</b>
                            </div>
                            <div class="step-one-number">
                                <div class="step-one-number-container">
                                    <img src="{{ asset('img/euflag.png') }}" alt="">
                                    <input type="text" v-model="num" name="registrar" placeholder="123NRO">
                                </div>
                                <span class="Lato">Käyttämällä tilauspalvelua hyväksyt <a href="{{ route('rules') }}">tietosuojaselosteen</a></span>
                            </div>
                        </div>
                    </div>
                    <style>
                        .step-one-component input[type=radio] {
                            visibility: hidden;
                            position: absolute;
                        }

                        label > input + img {
                            cursor: pointer;
                            border: 2px solid transparent;
                        }

                        label > input:checked + img {
                            border: 2px solid #f00;
                        }
                    </style>
                </section>

                <section class="step2" v-bind:class="{ section_active: step >= 2} ">

                    <div class="map-back" v-on:click="back()">
                        <img src="{{ asset('img/back.svg') }}" alt="">
                    </div>

                    <input type="text" id="adress__location_dup" name="adress__location" hidden>


                    <div id="unique__google">
                        <input type="text" id="adress__location" placeholder="Syötä sijainti"
                               value="@if(isset($data)) {{ $data->adress }} @endif" name="adress__location"
                               style="color: #FFF; border: none; padding: 3px; box-sizing:border-box" value="">
                        <div id="infowindow-content"><span id="place-name" class="title"></span><br/><span
                                id="place-address"></span></div>
                    </div>
                    <div id="map"></div>

                    <div class="step2-go-button">
                        <div class="step2-button Bebas" v-on:click="go()" id="step2button" style="display: none">jatka
                            eteenpäin
                        </div>
                    </div>

                    <div class="order-controller" v-if="(step > 2 && step < 5) || step == 7"
                         v-bind:class="{ order_controller_step_6: step >= 5 && step < 7}" style="position: relative">
                        <div class="order-controller-container">
                            <div class="order-controller-back" v-on:click="back()">
                                <img src="{{ asset('img/back.svg') }}" alt="">
                            </div>
                            <div class="order-controller-panel">
                                <div class="order-controller-line"></div>
                                <div class="order-controller-steps">
                                    <div class="order-controller-step" v-on:click="goStep(3)"
                                         v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(4)"
                                         v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(5)"
                                         v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(6)"
                                         v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(7)"
                                         v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
                                </div>
                            </div>
                            <div class="order-controller-close" v-on:click="toBegin()">
                                <img src="{{ asset('img/close.png') }}" alt="">
                            </div>
                        </div>
                    </div>

                </section>

                <section class="step3" v-bind:class="{ section_active: step >= 3} ">
                    <input type="hidden" name="order__type" v-bind:value='orderType'>
                    <div class="step3-container">
                        <h1>Haluan... </h1>
                        <div class="step3-column" style="display: none"
                             v-on:click="go(); setType('premium', 3); rise(3,{{ $prices->step3_1 }})">
                            <div class="step3-title step-row">
                                <span>PREMIUM</span>
                            </div>
                            <div class="step3-img step-row">
                                <img src="{{ asset('img/step3_1.png') }}" alt="">
                            </div>
                            <div class="step3-span step-row">
                                <span style="text-transform: uppercase">yksittäisen maskottipesun</span>
                            </div>
                        </div>
                        <div class="step3-column"
                             v-on:click="go(); setType('standard', 3); rise(3,{{ $prices->step3_2 }})">
                            <div class="step3-title step-row">
                                <span>STANDARD</span>
                            </div>
                            <div class="step3-img step-row">
                                <img src="{{ asset('img/step3_2.png') }}" alt="">
                            </div>
                            <div class="step3-span step-row">
                                <span>YKSITTÄISEN PESUN</span>
                            </div>
                        </div>
                        <div class="step3-column" v-on:click="setModal()">
                            <div class="step3-title step-row">
                                <span>YRITYKSILLE</span>
                            </div>
                            <div class="step3-img step-row">
                                <img src="{{ asset('img/step3_3.png') }}" alt="">
                            </div>
                            <div class="step3-span step-row">
                                <span>RÄÄTÄLÖITYÄ PESURATKAISUA</span>
                            </div>
                        </div>
                    </div>
                    <div class="order-controller" v-if="(step > 2 && step < 5) || step == 7"
                         v-bind:class="{ order_controller_step_6: step >= 5 && step < 7}" style="position: relative">
                        <div class="order-controller-container">
                            <div class="order-controller-back" v-on:click="back()">
                                <img src="{{ asset('img/back.svg') }}" alt="">
                            </div>
                            <div class="order-controller-panel">
                                <div class="order-controller-line"></div>
                                <div class="order-controller-steps">
                                    <div class="order-controller-step" v-on:click="goStep(3)"
                                         v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(4)"
                                         v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(5)"
                                         v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(6)"
                                         v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(7)"
                                         v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
                                </div>
                            </div>
                            <div class="order-controller-close" v-on:click="toBegin()">
                                <img src="{{ asset('img/close.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                </section>

                <section class="step4" v-bind:class="{ section_active: step >= 4} ">

                    <div class="step4-container-text"
                         style="color: #FFF; text-align: center; margin-top: 30px; font-size: 26px;"><h1>Valitse autosi
                            tyyppi</h1></div>

                    <input type="hidden" name="car__type" v-bind:value='carType'>
                    <div class="step4-list">
                        <div class="step4-block" v-on:click="go(); setType('Sedan', 4); rise(5,{{ $prices->step4_1 }})">
                            <div class="step4-title">
                                <div class="step3-title step-row">
                                    <span>suosituin!</span>
                                </div>
                            </div>
                            <div class="step4-img">
                                <img src="{{ asset('img/step4_1.png') }}" alt="">
                            </div>
                            <div class="step4-text">
                                <span>SEDAN</span>
                            </div>
                        </div>
                        <div class="step4-block"
                             v-on:click="go(); setType('Farmari', 4); rise(5,{{ $prices->step4_2 }})">
                            <div class="step4-title">
                                <h1></h1>
                            </div>
                            <div class="step4-img">
                                <img src="{{ asset('img/step4_2.png') }}" alt="">
                            </div>
                            <div class="step4-text">
                                <span>FARMARI</span>
                            </div>
                        </div>
                        <div class="step4-block"
                             v-on:click="go(); setType('Korkea', 4); rise(5,{{ $prices->step4_3 }})">
                            <div class="step4-title">
                                <h1></h1>
                            </div>
                            <div class="step4-img">
                                <img src="{{ asset('img/step4_3.png') }}" alt="">
                            </div>
                            <div class="step4-text">
                                <span>PAKETTIAUTO (KORKEA)</span>
                            </div>
                        </div>
                        <div class="step4-block"
                             v-on:click="go(); setType('Matala', 4); rise(5,{{ $prices->step4_4 }})">
                            <div class="step4-title">
                                <h1></h1>
                            </div>
                            <div class="step4-img">
                                <img src="{{ asset('img/step4_4.png') }}" alt="">
                            </div>
                            <div class="step4-text">
                                <span>PAKETTIAUTO (MATALA)</span>
                            </div>
                        </div>
                        <div class="step4-block"
                             v-on:click="go(); setType('MAASTOAUTO', 4); rise(5,{{ $prices->step4_5 }})">
                            <div class="step4-title">
                                <h1></h1>
                            </div>
                            <div class="step4-img">
                                <img src="{{ asset('img/step4_5.png') }}" alt="">
                            </div>
                            <div class="step4-text">
                                <span>MAASTOAUTO</span>
                            </div>
                        </div>
                        <div class="step4-block" style="opacity: 0">

                        </div>
                    </div>
                    <div class="order-controller" v-if="(step > 2 && step < 5) || step == 7"
                         v-bind:class="{ order_controller_step_6: step >= 5 && step < 7}" style="position: relative">
                        <div class="order-controller-container">
                            <div class="order-controller-back" v-on:click="back()">
                                <img src="{{ asset('img/back.svg') }}" alt="">
                            </div>
                            <div class="order-controller-panel">
                                <div class="order-controller-line"></div>
                                <div class="order-controller-steps">
                                    <div class="order-controller-step" v-on:click="goStep(3)"
                                         v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(4)"
                                         v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(5)"
                                         v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(6)"
                                         v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(7)"
                                         v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
                                </div>
                            </div>
                            <div class="order-controller-close" v-on:click="toBegin()">
                                <img src="{{ asset('img/close.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                </section>

                <section class="step5" v-bind:class="{ section_active: step >= 5} ">
                    <div class="order-controller" v-if="step > 2" v-bind:class="{ order_controller_step_6: step >= 5}">
                        <div class="order-controller-container">
                            <div class="order-controller-back" v-on:click="back()">
                                <img src="{{ asset('img/back.svg') }}" alt="">
                            </div>
                            <div class="order-controller-panel">
                                <div class="order-controller-line"></div>
                                <div class="order-controller-steps">
                                    <div class="order-controller-step" v-on:click="goStep(3)"
                                         v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(4)"
                                         v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(5)"
                                         v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(6)"
                                         v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(7)"
                                         v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
                                </div>
                            </div>
                            <div class="order-controller-close" v-on:click="toBegin()">
                                <img src="{{ asset('img/close.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="step5-container">
                        <div class="step5-first">
                            <div class="step-field"><img src="{{ asset('img/step5_1.png') }}" alt=""><span>@{{ orderType }}</span>
                            </div>
                            <div class="step-field"><img src="{{ asset('img/step5_2.png') }}" alt=""><span>@{{ mainType }}</span>
                            </div>
                            <div class="step-field"><span>ASETUKSET</span></div>
                        </div>

                        <div class="step5-text">
                        <span>
                            Valitse sinulle sopivin pesu. Samoin voit tilata lisäpalveluita:
                        </span>
                        </div>


                        <div class="step5-checkboxex">
                            <div class="step5-checkbox"><span>Hyönteistenpoisto {{ $prices->step5_1 }}€</span><input
                                    type="checkbox" class="custom-checkbox" id="rb1" name=""
                                    v-on:click="checkBoxMethod(1,{{ $prices->step5_1 }})" v-model="checked1"><label
                                    for="rb1"></label></div>
                            <div class="step5-checkbox"><span>Karvojenpoisto {{ $prices->step5_2 }}€</span><input
                                    type="checkbox" class="custom-checkbox" id="rb2" name=""
                                    v-on:click="checkBoxMethod(2,{{ $prices->step5_2 }})" v-model="checked2"><label
                                    for="rb2"></label></div>
                            <div class="step5-checkbox"><span>Renkaiden vaihto {{ $prices->step5_3 }}€</span><input
                                    type="checkbox" class="custom-checkbox" id="rb3" name=""
                                    v-on:click="checkBoxMethod(3,{{ $prices->step5_3 }})" v-model="checked3"><label
                                    for="rb3"></label></div>
                        </div>
                        <input type="hidden" id="zipCodes" value='{!! $zipCodes->toJson() !!}' name="zipCodes">
                        <input type="hidden" name="checked1" v-bind:value="checked1">
                        <input type="hidden" name="checked2" v-bind:value="checked2">
                        <input type="hidden" name="checked3" v-bind:value="checked3">
                        <input type="hidden" name="param1" v-bind:value="active1">
                        <input type="hidden" name="param2" v-bind:value="active2">
                        <input type="hidden" name="param3" v-bind:value="active3">
                        <input type="hidden" name="param4" v-bind:value="active4">
                        <input type="hidden" name="priceCheck1" value="{{ $prices->step5_1 }}">
                        <input type="hidden" name="priceCheck2" value="{{ $prices->step5_2 }}">
                        <input type="hidden" name="priceCheck3" value="{{ $prices->step5_3 }}">
                        <input type="hidden" name="price1" v-bind:value="price61">
                        <input type="hidden" name="price2" v-bind:value="price62">
                        <input type="hidden" name="price3" v-bind:value="price63">
                        <input type="hidden" name="price4" v-bind:value="price64">
                        <input type="hidden" name="additionalPrice" v-bind:value="additionalPrice">
                        <input type="hidden" name="postal_code" id="postal_code" value="">
                        <input type="hidden" name="zip_price" id="zip_price" value="0" ref="zipPrice">

                        <div class="step5-action-list">


                            <div class="step5-action" v-if="mainType == 'Ulkopesu'"
                                 v-bind:class="{action_active: active1}"
                                 v-on:click="setActive(1, {!! $prices->ulk1 !!}, {!! $prices->ulk1_time !!})"><span class="action-text">Ulkopesu + vaha</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Kevytvaha</li>
                                    <li><b>·</b> Hyönteistenpoisto +10 €</li>
                                    <li><b>·</b> Renkaiden vaihto +39 €</li>
                                </ul>
                                <span class="action-price"><b>+@{{ ulk1+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Ulkopesu'"
                                 v-bind:class="{action_active: active4}"
                                 v-on:click="setActive(4, {!! $prices->ulk4 !!}, {!! $prices->ulk4_time !!})"><span
                                    class="action-text">MASKOTTIPESU</span>
                                <ul>
                                    <li><b>·</b> PESUMAESTROMME ON PUKEUTUNUT APINA PUKUUN</li>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Hyönteistenpoisto</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                </ul>
                                <span class="action-price"><b>+@{{ ulk4+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Ulkopesu'"
                                 v-bind:class="{action_active: active2}"
                                 v-on:click="setActive(2, {!! $prices->ulk2 !!}, {!! $prices->ulk2_time !!})"><span class="action-text">Ulkopesu + pro</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Hyönteistenpoisto</li>
                                    <li><b>·</b> Rengaskiilto</li>esu</li>
                                    <li><b>·</b> Kevytvaha</li>
                                    <li><b>·</b> Kromiosien kiilloitus</li>
                                    <li><b>·</b> Renkaiden vaihto +39 €</li>
                                </ul>
                                <span class="action-price"><b>+@{{ ulk2+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Ulkopesu'"
                                 v-bind:class="{action_active: active3}"
                                 v-on:click="setActive(3, {!! $prices->ulk3 !!}, {!! $prices->ulk3_time !!})"><span class="action-text">Ulkopesu + kerramien pinnoite</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Hyönteistenpoisto</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Kromiosien kiilloitus</li>
                                    <li><b>·</b> Keraaminen pinnoite (kesto 6kk)</li>
                                    <li><b>·</b> Renkaiden vaihto +39 €</li>
                                </ul>
                                <span class="action-price"><b>+@{{ ulk3+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Sisäpesu'"
                                 v-bind:class="{action_active: active1}"
                                 v-on:click="setActive(1, {!! $prices->sis1 !!}, {!! $prices->sis1_time !!})"><span class="action-text">Perus Sisäpesu</span>
                                <ul>
                                    <li><b>·</b> Imurointi</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Yleisten pintojen pyyhintä</li>
                                    <li><b>·</b> Ikkunoidenpesu</li>
                                    <li><b>·</b> Roskien poisto</li>
                                    <li><b>·</b> Karvojenpoisto +20€</li>
                                </ul>
                                <span class="action-price"><b>+@{{ sis1+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Sisäpesu'"
                                 v-bind:class="{action_active: active2}"
                                 v-on:click="setActive(2, {!! $prices->sis2 !!}, {!! $prices->sis2_time !!})"><span class="action-text">Premium Sisäpesu</span>
                                <ul>
                                    <li><b>·</b> Imurointi (sis. tavaratila)</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Penkkien syväpesu / nahkapenkkien pesu (5 istuinta)</li>
                                    <li><b>·</b> Pintojen pesu</li>
                                    <li><b>·</b> Ovien pesu</li>
                                    <li><b>·</b> Ikkunoiden pesu</li>
                                    <li><b>·</b> Roskien poisto</li>
                                </ul>
                                <span class="action-price"><b>+@{{ sis2+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Sisäpesu'"
                                 v-bind:class="{action_active: active3}"
                                 v-on:click="setActive(3, {!! $prices->sis3 !!}, {!! $prices->sis3_time !!})"><span class="action-text">Luksus Sisäpesu</span>
                                <ul>
                                    <li><b>·</b> Imurointi (sis. tavaratila)</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Kangas penkkien syväpesu / nahkapenkkien pesu (5 istuinta)</li>
                                    <li><b>·</b> Jokaisen pinnan sekä kolon/raon pesu, desinfiointi + kiilloitus</li>
                                    <li><b>·</b> Nahanhoito</li>
                                    <li><b>·</b> Suoja-aineiden laitto jokaiselle pinnalle</li>
                                    <li><b>·</b> Ikkunoiden pesu</li>
                                    <li><b>·</b> Roskien poisto</li>
                                    <li><b>·</b> Karvojenpoisto</li>
                                    <li><b>·</b> Ilmanraikastin (valinnainen)</li>
                                    
                                </ul>
                                <span class="action-price"><b>+@{{ sis3+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Molemmat'"
                                 v-bind:class="{action_active: active1}"
                                 v-on:click="setActive(1, {!! $prices->mol1 !!}, {!! $prices->mol1_time !!})"><span class="action-text">PERUS SISÄPESU + ULKOPESU</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Kevytvaha</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Imurointi</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Yleisten pintojen pyyhintä</li>
                                    <li><b>·</b> Roskien poisto</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                </ul>
                                <span class="action-price"><b>+@{{ mol1+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Molemmat'"
                                 v-bind:class="{action_active: active2}"
                                 v-on:click="setActive(2, {!! $prices->mol2 !!}, {!! $prices->mol2_time !!})"><span class="action-text">PREMIUM SISÄPESU + ULKOPESU</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Kevytvaha</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Imurointi</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Pintojen pesu</li>
                                    <li><b>·</b> Roskien poisto</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Ovien pesu</li>
                                    <li><b>·</b> Pintojen pesu</li>
                                    <li><b>·</b> Hyönteistenpoisto</li>
                                    <li><b>·</b> Ikkunoiden pesu</li>
                                    <li><b>·</b> Penkkien syväpesu / nahkapenkkien pesu (5 istuinta)</li>
                                </ul>
                                <span class="action-price"><b>+@{{ mol2+price5 }} €</b></span></div>
                            <div class="step5-action" v-if="mainType == 'Molemmat'"
                                 v-bind:class="{action_active: active3}"
                                 v-on:click="setActive(3, {!! $prices->mol3 !!}, {!! $prices->mol3_time !!})"><span class="action-text">LUKSUS SISÄPESU + ULKOPESU & KERAAMINEN PINNOITE</span>
                                <ul>
                                    <li><b>·</b> Ulkopesu</li>
                                    <li><b>·</b> Ovenvälienpesu</li>
                                    <li><b>·</b> Hyönteistenpoisto</li>
                                    <li><b>·</b> Rengaskiilto</li>
                                    <li><b>·</b> Kromiosien kiilloitus</li>
                                    <li><b>·</b> Keraaminen pinnoite (kesto 6kk)</li>
                                    <li><b>·</b> Imurointi (sis. tavaratila)</li>
                                    <li><b>·</b> Mattojenpesu</li>
                                    <li><b>·</b> Kangas penkkien syväpesu / nahkapenkkien pesu</li>
                                    <li><b>·</b> Jokaisen pinnan sekä kolon/raon pesu, desinfiointi + kiilloitus</li>
                                    <li><b>·</b> Nahanhoito</li>
                                    <li><b>·</b> Suoja-aineiden laitto jokaiselle pinnalle</li>
                                    <li><b>·</b> Ikkunoiden pesu</li>
                                    <li><b>·</b> Roskien poisto</li>
                                    <li><b>·</b> Karvojenpoisto</li>
                                    <li><b>·</b> Ilmanraikastin (valinnainen)</li>
                                </ul>
                                <span class="action-price"><b>+@{{ mol3+price5 }} €</b></span></div>
                            <!--
                        <div class="step5-action"  v-if="active1" v-bind:class="{action_active: active54}" v-on:click="setActive(5, {{ $prices->step5_4 }})"><span class="action-text">Pesumaestromme on pukeutunut Apinapukuun!</span><ul><li><b>·</b> ulkopesu</li><li><b>·</b> ovenvälienpesu</li><li><b>·</b> rengaskiilto</li><li><b>·</b> Hyönteistenpoisto</li></ul><span class="action-price"><b>+{{ $prices->step5_4 }} €</b></span></div>
                        <div class="step5-action"  v-bind:class="{action_active: active2}" v-on:click="setActive(2, {{ $prices->step6_2 }})"><span class="action-text">Perus Sisäpesu</span><ul><li><b>·</b> imurointi</li><li><b>·</b> mattojenpesu</li><li><b>·</b> pintojenpyyhintä</li><li><b>·</b> roskien poisto</li><li><b>·</b> ikkunoiden pesu</li></ul><span class="action-price"><b>+{{ $prices->step6_2 }} €</b></span></div>
                        <div class="step5-action"  v-bind:class="{action_active: active3}" v-on:click="setActive(3, {{ $prices->step6_3 }})"><span class="action-text">Kevyt Sisäpesu</span><ul><li><b>·</b> imurointi</li><li><b>·</b> mattojenpesu</li><li><b>·</b> pintojenpyyhintä</li><li><b>·</b> roskien poisto</li><li><b>·</b> ikkunoiden pesu</li><li><b>·</b> penkkien syväpesu</li></ul><span class="action-price"><b>+{{ $prices->step6_3 }} €</b></span></div>
                        <div class="step5-action"  v-bind:class="{action_active: active4}" v-on:click="setActive(4, {{ $prices->step6_4 }})"><span class="action-text">Luksus Sisäpesu</span><ul><li><b>·</b> imurointi</li><li><b>·</b> mattojenpesu</li><li><b>·</b> pintojenpyyhintä</li><li><b>·</b> roskien poisto</li><li><b>·</b> ikkunoiden pesu</li><li><b>·</b> penkkien syväpesu</li><li><b>·</b> ovien pesu</li></ul><span class="action-price"><b>+{{ $prices->step6_4 }} €</b></span></div>
                        -->
                        </div>

                        <div class="step5-buttons">
                            <div class="step5-button" style="margin-bottom: 40px;" v-on:click="go()"
                                 v-if="checked1 || checked2 || checked3 || active1 || active2 || active3 || active4">
                                Jatka eteenpäin <span class="price-button">@{{ price }} €</span></div>
                        </div>
                    </div>
                </section>

                <section class="step6" v-bind:class="{ section_active: step >= 6} ">
                    <div class="order-controller" v-if="step > 2" v-bind:class="{ order_controller_step_6: step >= 5}">
                        <div class="order-controller-container">
                            <div class="order-controller-back" v-on:click="back()">
                                <img src="{{ asset('img/back.svg') }}" alt="">
                            </div>
                            <div class="order-controller-panel">
                                <div class="order-controller-line"></div>
                                <div class="order-controller-steps">
                                    <div class="order-controller-step" v-on:click="goStep(3)"
                                         v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(4)"
                                         v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(5)"
                                         v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(6)"
                                         v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                                    <div class="order-controller-step" v-on:click="goStep(7)"
                                         v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
                                </div>
                            </div>
                            <div class="order-controller-close" v-on:click="toBegin()">
                                <img src="{{ asset('img/close.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="step6-container">
                        <div class="step6-date" style="padding-top: 100px">
                            <div class="step6-date-container">
                                <span class="date-back" v-on:click="dayBack()"><img
                                        src="https://www.svgrepo.com/show/365208/caret-right-thin.svg" alt=""></span>
                                <span class="date-text">@{{ day }}. @{{ months[month] }}</span>
                                <span class="date-forward" v-on:click="dayForward()"><img
                                        src="https://www.svgrepo.com/show/365208/caret-right-thin.svg" alt=""></span>
                            </div>
                        </div>

                        <div class="step6-time">
                            <div class="step6-time-container">
                                <div class="step6-times">
                                    <input type="hidden" name="day" v-bind:value="day">
                                    <input type="hidden" name="month" v-bind:value="month">
                                    <input type="hidden" name="time" v-bind:value="time">


                                    <div v-for="(value, index) in continuity" >
                                        <div
                                             v-bind:class="{ time_none: checkFlag(value), time_active: isTime == index+1 }"
                                             v-on:click="checkFlag(value) ? selectTime(index, value, 1) : selectTime(index+1, value, 0)"
                                             class="step6-time-block">
                                        <span class="time-container" v-if="isTime == index+1">
                                            <b>@{{ value }} (MAX)</b><br>
                                            <b>Kesto: @{{ getHours() }} tuntia</b><br>
                                            <ul>
                                                <li v-if="active1">Ulkopesu</li>
                                                <li v-if="active2">Ovenvälienpesu</li>
                                                <li v-if="active3">Rengaskiilto</li>
                                                <li v-if="active4">Kevytvaha</li>
                                            </ul>
                                        </span>
                                            <span class="text">@{{ value }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="step5-buttons">
                            <div class="step5-button" v-on:click="go()" v-if="isTime != 0">Jatka eteenpäin</div>
                        </div>
                    </div>
                </section>

                <section class="step7" v-bind:class="{ section_active: step >= 7} ">
                    <div class="step7-new-container">
                        <div class="step7-row">
                            <h1>tilauksesi</h1>
                        </div>
                        <div class="step7-row">
                            <div class="step7-info">
                                <div class="step7-info-block">
                                    <div class="step7-info-block-title">
                                        <span>PÄIVÄMÄÄRÄ</span>
                                    </div>
                                    <div class="step7-info-block-text"><span v-if="day <= 9">0</span>@{{ day }}-<span
                                            v-if="month+1 <= 9">0</span>@{{ month+1 }}-{!! date('Y'); !!}</div>
                                </div>
                                <div class="step7-info-block">
                                    <div class="step7-info-block-title">
                                        <span>AIKA</span>
                                    </div>
                                    <div class="step7-info-block-text">@{{ time }}</div>
                                </div>
                                <div class="step7-info-block">
                                    <div class="step7-info-block-title">
                                        <span>PAIKKA</span>
                                    </div>
                                    <div class="step7-info-block-text">@{{ adress }}</div>
                                </div>
                                <div class="step7-info-block">
                                    <div class="step7-info-block-title">
                                        <span>AUTO</span>
                                    </div>
                                    <div class="step7-info-block-text">@{{ num }}</div>
                                </div>
                            </div>
                        </div>

                        <div class="step7-row" style="padding:26px; box-sizing: border-box">
                            <h1 style="text-align: left; font-weight: 700">Pesu ja vahaus </h1>
                            <ul class="final-ul">
                                <li v-if="checked1">Hyönteistenpoisto <span>{!! $prices->step5_1 !!} €</span></li>
                                <li v-if="checked2">Karvojenpoisto <span>{!! $prices->step5_2 !!} €</span></li>
                                <li v-if="checked3">Renkaiden vaihto <span>{!! $prices->step5_3 !!} €</span></li>
                                <li v-if="additionalPrice > 0">Pesijän matkakulut <span>1,5 €</span></li>
                                {{--<li v-if="active1">Ulkopesu <span>{!! $prices->step6_1 !!} €</span></li>
                                <li v-if="active2">Ovenvälienpesu <span>{!! $prices->step6_2 !!} €</span></li>
                                <li v-if="active3">Rengaskiilto <span>{!! $prices->step6_3 !!} €</span></li>
                                <li v-if="active4">Kevytvaha <span>{!! $prices->step6_4 !!} €</span></li>--}}
                            </ul>
                            <div class="step7-pesu">
                                <div class="step7-pesu-left">max 60 minuuttia</div>
                                <div class="step7-pesu-right"><b id="stripe__price_unique">@{{ price }} €</b></div>
                            </div>
                        </div>
                        <div class="step7-line"></div>
                        <div class="step7-row" style="padding:26px; box-sizing: border-box">
                            <div class="step7-pesu">
                                <div class="step7-pesu-left" style="color:#9D9FB4">YHTEENSÄ</div>
                                <div class="step7-pesu-right"><b
                                        style="font-size: 24px; position: relative; bottom: 6px">@{{ price }} €</b>
                                </div>
                            </div>
                        </div>


                        @if(!Session::has('auth'))

                            <div class="step7-input" style="height: auto">
                                <input type="text" name="name" placeholder="Nimi" required>
                                <input type="text" name="secondname" placeholder="Sukunimi" required>
                                <input type="text" name="email" placeholder="Sähköposti" required>
                                <input type="text" name="phone" placeholder="Puhelinnumero" required>
                            </div>
                        @endif


                        <div class="step7-row">
                            <div class="step7-button" v-on:click="showInput(2)"><span>MINULLA ON KUPONKI</span></div>
                        </div>

                        <div class="step7-row">
                            <div class="step7-input" v-bind:class="{step7_active_input: isCupon}">
                                <input type="text" name="cupon" v-model="cupon" :placeholder="placeholder">
                                <div v-on:click="findPercent()"
                                     style="width: 100%; padding: 15px; box-sizing: border-box; background: #FF6600; text-align: center; color: #FFF; font-weight: 700; font-size: 22px; text-transform:uppercase; cursor:pointer;">
                                    aktivoi kuponki
                                </div>
                            </div>
                        </div>

                        <div class="step7-row">
                            <div class="step7-button" v-on:click="showInput(3)"><span>kommentti tilaukseen...</span>
                            </div>
                        </div>

                        <div class="step7-row">
                            <div class="step7-input" style="" v-bind:class="{step7_active_input: isComment}">
                                <textarea name="comment" id="" placeholder="Syötä kommentti…"></textarea>
                            </div>
                        </div>


                        <div class="step7-row">
                            <div class="step7-pay">
                                <form id="payment-form">

                                    <div id="payment-element">

                                    </div>

                                    <button id="submit">

                                        <div class="spinner hidden" id="spinner"></div>

                                        <span id="button-text">Tilaa pesu</span>

                                    </button>

                                    <div id="payment-message" class="hidden"></div>

                                </form>
                                <p style="max-width:300px;">Maksuyhteyden tarjoaa <a href="https://stripe.com/" target="_blank"><svg viewBox="0 0 60 25" xmlns="http://www.w3.org/2000/svg" width="60" height="25" class="UserLogo variant-- "><title>Stripe logo</title><path fill="var(--userLogoColor, #0A2540)" d="M59.64 14.28h-8.06c.19 1.93 1.6 2.55 3.2 2.55 1.64 0 2.96-.37 4.05-.95v3.32a8.33 8.33 0 0 1-4.56 1.1c-4.01 0-6.83-2.5-6.83-7.48 0-4.19 2.39-7.52 6.3-7.52 3.92 0 5.96 3.28 5.96 7.5 0 .4-.04 1.26-.06 1.48zm-5.92-5.62c-1.03 0-2.17.73-2.17 2.58h4.25c0-1.85-1.07-2.58-2.08-2.58zM40.95 20.3c-1.44 0-2.32-.6-2.9-1.04l-.02 4.63-4.12.87V5.57h3.76l.08 1.02a4.7 4.7 0 0 1 3.23-1.29c2.9 0 5.62 2.6 5.62 7.4 0 5.23-2.7 7.6-5.65 7.6zM40 8.95c-.95 0-1.54.34-1.97.81l.02 6.12c.4.44.98.78 1.95.78 1.52 0 2.54-1.65 2.54-3.87 0-2.15-1.04-3.84-2.54-3.84zM28.24 5.57h4.13v14.44h-4.13V5.57zm0-4.7L32.37 0v3.36l-4.13.88V.88zm-4.32 9.35v9.79H19.8V5.57h3.7l.12 1.22c1-1.77 3.07-1.41 3.62-1.22v3.79c-.52-.17-2.29-.43-3.32.86zm-8.55 4.72c0 2.43 2.6 1.68 3.12 1.46v3.36c-.55.3-1.54.54-2.89.54a4.15 4.15 0 0 1-4.27-4.24l.01-13.17 4.02-.86v3.54h3.14V9.1h-3.13v5.85zm-4.91.7c0 2.97-2.31 4.66-5.73 4.66a11.2 11.2 0 0 1-4.46-.93v-3.93c1.38.75 3.1 1.31 4.46 1.31.92 0 1.53-.24 1.53-1C6.26 13.77 0 14.51 0 9.95 0 7.04 2.28 5.3 5.62 5.3c1.36 0 2.72.2 4.09.75v3.88a9.23 9.23 0 0 0-4.1-1.06c-.86 0-1.44.25-1.44.9 0 1.85 6.29.97 6.29 5.88z" fill-rule="evenodd"></path></svg></a></p>
                            </div>
                        </div>

                        <div class="step7-row">
                            <div class="step7-input" style="height: auto">
                                <input type="submit" value="TILAA PESU">
                            </div>
                        </div>

    </form>
</div>
<div class="order-controller" v-if="(step > 2 && step < 5) || step == 7"
     v-bind:class="{ order_controller_step_6: step >= 5 && step < 7}" style="position: relative">
    <div class="order-controller-container">
        <div class="order-controller-back" v-on:click="back()">
            <img src="{{ asset('img/back.svg') }}" alt="">
        </div>
        <div class="order-controller-panel">
            <div class="order-controller-line"></div>
            <div class="order-controller-steps">
                <div class="order-controller-step" v-on:click="goStep(3)"
                     v-bind:class="{ order_controller_active_line: step == 3, order_controller_step_active: step > 3} "></div>
                <div class="order-controller-step" v-on:click="goStep(4)"
                     v-bind:class="{ order_controller_active_line: step == 4, order_controller_step_active: step > 4} "></div>
                <div class="order-controller-step" v-on:click="goStep(5)"
                     v-bind:class="{ order_controller_active_line: step == 5, order_controller_step_active: step > 5} "></div>
                <div class="order-controller-step" v-on:click="goStep(6)"
                     v-bind:class="{ order_controller_active_line: step == 6, order_controller_step_active: step > 6} "></div>
                <div class="order-controller-step" v-on:click="goStep(7)"
                     v-bind:class="{ order_controller_active_line: step == 7, order_controller_step_active: step > 7} "></div>
            </div>
        </div>
        <div class="order-controller-close" v-on:click="toBegin()">
            <img src="{{ asset('img/close.png') }}" alt="">
        </div>
    </div>
</div>
</section>
</div>

<div class="button-create-order" v-if="step < 2">
    <div class="button" v-on:click="click()" v-bind:class="{ rotate: step == 1} "><span>+</span></div>
</div>


<div class="modal-container" v-if="modal">
    <div class="back" v-on:click="setModal()" style="position: relative; top: 20px; left: 20px;">
        <img src="{{ asset('img/back.svg') }}" alt="" style=" width: 50px; height: 50px;">
    </div>
    <form action="{{ route('sendMail') }}" method="POST">
        @csrf
        <div class="modal step7-input" style="height: auto;">
            <fieldset>
                <h4>Haluatko autopesu sopimuksen?
                    Jätä tiedot niin olemme teihin
                    pikimmiten yhteydessä!
                    Sopimusasiakkaana saat pesut
                    vähintään -10% hintaan.
                    Työntekijäsi tilaavat pesut myös
                    alennettuun hintaan.
                </h4>

                <input type="text" name="interval" placeholder="Haluttu pesuväli: (esim. kerran kuukaudessa)"
                       required="required">
                <input type="text" name="where" placeholder="Sisäpesut, ulkopesut vaiko molemmat?" required="required">
                <input type="text" name="amount"
                       placeholder="Kuinka monta ajoneuvoa yrityksellä on ja minkälaisia? (esim. pakettiautoja, kuorma-autoja)"
                       required="required">
            </fieldset>
            <fieldset>
                <h4>Yrityksen tiedot</h4>

                <input type="text" name="name" placeholder="Nimi" required="required">
                <input type="text" name="ytun" placeholder="Y-tunnus" required="required">
                <input type="text" name="adress" placeholder="Osoite" required="required">
                <input type="text" name="index" placeholder="Postinumero" required="required">
                <input type="text" name="indexStreet" placeholder="Postitoimipaikka" required="required">
            </fieldset>
            <fieldset>
                <h4>Yhteyshenkilö</h4>
                <input type="text" name="nameAndSecondname" placeholder="Etu- ja sukunimi" required="required">
                <input type="text" name="email" placeholder="Sähköpostiosoite" required="required">
                <input type="text" name="phone" placeholder="Puhelinnumero" required="required">
            </fieldset>
            <input type="submit" value="Lähetä tiedot" style="cursor: pointer;">
        </div>
    </form>
</div>

<footer>
    <div class="footer-container">
        @if(Session::has('auth'))
            <a href="{{ route('last') }}" v-if="step == 0" style="z-index: 9999999" class="footer-left"><img
                    src="{{ asset('img/time.png') }}" alt=""></a>
        @endif
        <a href="{{ route('profile') }}" v-if="step == 0" class="footer-right"><img src="{{ asset('img/profile.png') }}"
                                                                                    alt=""></a>
    </div>
</footer>
</div>


</div>
<style>
    .custom-map-control-button {
        padding: 10px;
        background: #FFF;
        color: #333;
        display: block;
        padding-left: 20px;
        padding-right: 20px;
        margin-top: 20px;
        font-size: 18px;
        cursor: pointer;
    }

    .step7-pay #submit {
        display: none;
    }

    .gm-ui-hover-effect {
        display: none !important;
    }
</style>
</body>

@php $day_z = date("d", strtotime("+1 day")); $month_z = date("m", strtotime("+1 day"))-1; @endphp

@if(isset($data))
    @php $num = $data->auto; @endphp
@endif

<script>

    var app = new Vue({
        el: '#app',
        data: {
            step: 0,
            @if(isset($num)) num: "{!! $num !!}", @else num: "", @endif
            orderType: "none",
            carType: "none",
            modal: false,
            adress: "",
            time: "",
            date: "",
            month: {!! $month_z !!},
            day: {!! $day_z !!},
            months: ['Tammikuu', 'Helmikuu', 'Maaliskuu', 'Huhtikuu', 'Toukokuu', 'Kesäkuu', 'Heinäkuu', 'Elokuu', 'Syyskuu', 'Lokakuu', 'Marraskuu', 'Joulukuu'],
            isTime: 0,
            isDay: 0,
            mainType: "none",
            checked1: false,
            checked2: false,
            checked3: false,
            active1: false,
            active2: false,
            active3: false,
            active4: false,
            active54: false,
            price1: 0,
            price3: 0,
            price41: 0,
            price42: 0,
            price43: 0,
            price44: 0,
            price5: 0,
            price61: 0,
            price62: 0,
            price63: 0,
            price64: 0,
            price: 0,
            additionalPrice: {{ $orders > 0 ? 1.5 : 0 }},
            isAuth: 0,
            isComment: 0,
            isCupon: 0,
            cuponActivated: 0,
            cupon: null,
            placeholder: "KUPONKI",
            continues: 0,
            times: {!! $times->toJson() !!},
            zipCodes: {!! $zipCodes->toJson() !!},
            flag: false,
            zipPrice: 0,


            ulk1: {!! $prices->ulk1 !!},
            ulk2: {!! $prices->ulk2 !!},
            ulk3: {!! $prices->ulk3 !!},
            ulk4: {!! $prices->ulk4 !!},
            sis1: {!! $prices->sis1 !!},
            sis2: {!! $prices->sis2 !!},
            sis3: {!! $prices->sis3 !!},
            mol1: {!! $prices->mol1 !!},
            mol2: {!! $prices->mol2 !!},
            mol3: {!! $prices->mol3 !!},

            ulk1_time: {!! $prices->ulk1_time !!},
            ulk2_time: {!! $prices->ulk2_time !!},
            ulk3_time: {!! $prices->ulk3_time !!},
            ulk4_time: {!! $prices->ulk4_time !!},
            sis1_time: {!! $prices->sis1_time !!},
            sis2_time: {!! $prices->sis2_time !!},
            sis3_time: {!! $prices->sis3_time !!},
            mol1_time: {!! $prices->mol1_time !!},
            mol2_time: {!! $prices->mol2_time !!},
            mol3_time: {!! $prices->mol3_time !!},
            continuity: [],
        },
        methods: {
            getHours(){
              return Math.round((this.continues/60)*100)/100;
            },
            changePostal(event){
                console.log(event.value)
            },
            checkFlag(timeInterval){
                let flag = false;
                let dayChecked = false;
                let monthChecked = false;
                for(let t in this.times){
                    if(this.times[t].time == timeInterval){
                        flag = true;
                        dayChecked = this.times[t].time_d;
                        monthChecked = this.times[t].time_m;
                    }
                }

                return flag && (this.day == dayChecked && (this.month == monthChecked - 1));

            },
            setModal() {
                if (this.modal) this.modal = false;
                else this.modal = true;
            },
            findPercent() {
                if (this.cuponActivated == 0) {
                    @foreach($cupons as $cupon)
                        @php
                            $dateFrom = explode('-',$cupon->date);
                            $dateTo = explode('-',$cupon->dateTo);
                            $day_from = $dateFrom[2];
                            $day_to = $dateTo[2];
                            $month_from = $dateFrom[1];
                            $month_to = $dateTo[1];
                            $year_to = $dateTo[0];
                            $year_from = $dateFrom[0];
                        @endphp
                        @if(date('d') >= $day_from && date('m') >= $month_from && '20'.date('y') >= $year_from && date('d') <= $day_to && date('m') <= $month_to && '20'.date('y') <= $year_to )
                    if (this.cupon == "{{ $cupon->code }}") {
                        percent = this.price * ({{ $cupon->percent }} / 100);
                        this.price = this.price - percent;
                        this.price = this.price.toFixed();
                        this.cuponActivated = 1;
                        setTimeout(function(){
                            paymentInitialize();
                            checkStatus();
                        }, 200);
                        
                    }
                    @endif
                    @endforeach
                }
            },
            goStep(step) {
                if (this.step > step) {
                    this.step = step;
                }
            },
            showInput(id) {
                if (id == 1) {
                    this.isAuth = 1;
                    this.isComment = 0;
                    this.isCupon = 0;
                }
                if (id == 2) {
                    this.isAuth = 0;
                    this.isComment = 0;
                    this.isCupon = 1;
                }
                if (id == 3) {
                    this.isAuth = 0;
                    this.isComment = 1;
                    this.isCupon = 0;
                }
            },
            dayForward() {
                if (this.month + 1 != 12) {
                    if (this.month == 0 || this.month == 2 || this.month == 4 || this.month == 6 || this.month == 8 || this.momth == 10) {
                        if (this.day + 1 != 32) {
                            this.day += 1;
                        } else {
                            this.day = 1;
                            this.month += 1;
                        }
                    } else {
                        if (this.day + 1 != 31) {
                            this.day += 1;
                        } else {
                            this.day = 1;
                            this.month += 1;
                        }
                    }
                } else {
                    if (this.day + 1 != 32) {
                        this.day += 1;
                    } else {
                        this.day = 1;
                        this.month = 0;
                    }
                }

            },
            dayBack() {
                if ((this.day - 1 >= {!! $day_z !!} && this.month == {!! $month_z !!}) || this.month > {!! $month_z !!})
                    if (this.month - 1 != -1) {
                        if (this.month == 0 || this.month == 2 || this.month == 4 || this.month == 6 || this.month == 8 || this.momth == 10) {
                            if (this.day - 1 != 0) {
                                this.day -= 1;
                            } else {
                                this.day = 31;
                                this.month -= 1;
                            }
                        } else {
                            if (this.day - 1 != 0) {
                                this.day -= 1;
                            } else {
                                this.day = 30;
                                this.month -= 1;
                            }
                        }
                    } else {
                        if (this.day - 1 != 0) {
                            this.day -= 1;
                        } else {
                            this.day = 30;
                            this.month = 11;
                        }
                    }
            },
            selectTime(num, string, isBlock) {
                if (isBlock == 0) {
                    this.isTime = num;
                    this.time = string;
                }
            },
            go() {
                if(this.step > 5){
                    paymentInitialize();
                    checkStatus();
                }
                this.zipPrice = parseFloat(this.$refs.zipPrice.value ?? 0);
                this.adress = document.getElementById("adress__location").value;
                if (this.step + 1 > 7) {
                    this.step = 7;
                } else {
                    this.step = this.step + 1;
                }
            },
            back() {
                if (this.step - 1 < 0) {
                    this.step = 0;
                } else {
                    this.step = this.step - 1;
                }
            },
            click() {
                if (this.step == 0)
                    this.step = 1;
                else
                    this.step = 0;
            },
            toBegin() {
                this.step = 0;
            },
            setType(type, step) {
                if (step == 3) {
                    this.orderType = type;
                }

                if (step == 4) {
                    this.carType = type;
                }
            },
            rise(step, sum) {
                if (step == 1) {
                    this.price = 0;
                    this.price1 = 0;
                    this.price1 = this.price1 + sum;
                    this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                }
                if (step == 3) {
                    this.price = 0;
                    this.price3 = 0;
                    this.price3 = this.price1 + sum;
                    this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                }
                if (step == 5) {
                    this.price = 0;
                    this.price5 = 0;
                    this.price5 = this.price5 + sum;
                    this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                }
            },
            checkBoxMethod(box, sum) {
                if (box == 1) {
                    if (this.checked1 == false) {
                        this.price = 0;
                        this.price41 = this.price41 + sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    } else {
                        this.price = 0;
                        this.price41 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    }
                }
                if (box == 2) {
                    if (this.checked2 == false) {
                        this.price = 0;
                        this.price42 = this.price42 + sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    } else {
                        this.price = 0;
                        this.price42 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    }
                }
                if (box == 3) {
                    if (this.checked3 == false) {
                        this.price = 0;
                        this.price43 = this.price43 + sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    } else {
                        this.price = 0;
                        this.price43 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                    }
                }
                if (box == 4) {
                    this.price = 0;
                    this.price44 = this.price44 + sum;
                    this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice;
                }
            },
            setActive(step, sum, time) {
                if (step == 1) {
                    if (this.active1 == false) {
                        this.continues+=time;
                        this.active1 = true;
                        this.price61 = sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    } else {
                        this.continues-=time;
                        this.active1 = false;
                        this.price61 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    }
                }
                if (step == 2) {
                    if (this.active2 == false) {
                        this.continues+=time;
                        this.active2 = true;
                        this.price62 = sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    } else {
                        this.continues-=time;
                        this.active2 = false;
                        this.price62 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    }
                }
                if (step == 3) {
                    if (this.active3 == false) {
                        this.continues+=time;
                        this.active3 = true;
                        this.price63 = sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    } else {
                        this.continues-=time;
                        this.active3 = false;
                        this.price63 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    }
                }
                if (step == 4) {
                    if (this.active4 == false) {
                        this.continues+=time;
                        this.active4 = true;
                        this.price64 = sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    } else {
                        this.continues-=time;
                        this.active4 = false;
                        this.price64 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    }
                }
                if (step == 5) {
                    if (this.active54 == false) {
                        this.continues+=time;
                        this.active54 = true;
                        this.price5 = sum;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    } else {
                        this.continues-=time;
                        this.active54 = false;
                        this.price5 = 0;
                        this.price = this.price1 + this.price3 + this.price41 + this.price42 + this.price43 + this.price44 + this.price5 + this.price61 + this.price62 + this.price63 + this.price64 + this.additionalPrice + this.zipPrice;
                    }
                }

                this.continuity = [];
                if(this.continues != 0){
                    for(let i=540; i <= 1140; i+=this.continues){
                        let minutes = i;
                        let minute = minutes % 60;
                        let hours = Math.floor(minutes / 60);
                        minute = minute < 10 ? '0' + minute : minute;
                        hours = hours < 10 ? '0' + hours : hours;
                        hours = hours + ':' + minute;

                        let minutes_next = i + this.continues;
                        let minute_next = minutes_next % 60;
                        let hours_next = Math.floor(minutes_next / 60);
                        minute_next = minute_next < 10 ? '0' + minute_next : minute_next;
                        hours_next = hours_next < 10 ? '0' + hours_next : hours_next;
                        hours_next = hours_next + ':' + minute_next;
                        this.continuity.push(hours + '-' + hours_next);
                    }
                }
            }
        },
        mounted() {
            let recaptchaScript = document.createElement('script')
            recaptchaScript.setAttribute('src', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB7ZrPl6qQ98pf1QLbur5DYjf2bFgcMFOs&region=FI&language=en&callback=initialize&libraries=places&v=weekly')
            document.head.appendChild(recaptchaScript)

            let pay = document.createElement('script')
            pay.setAttribute('src', 'https://js.stripe.com/v3/')
            document.head.appendChild(pay)
        },
    })

</script>
<script>
    window.onload = function () {
        document.body.classList.add('loaded_hiding');
        window.setTimeout(function () {
            document.body.classList.add('loaded');
            document.body.classList.remove('loaded_hiding');
        }, 500);
    }
</script>

<script>
    $(document).keypress(
        function (event) {
            if (event.which == '13') {
                event.preventDefault();
            }
        });
</script>


<script type="text/javascript">
    function BrowserDetection() {

        //Check if browser is Safari, if it is, hide the <video> tag, otherwise hide the <img> tag
        if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
            document.getElementById('video-tagz').style.display = "none";
        } else {
            document.getElementById('img-tag').style.display = "none";
        }
    }

    //And run the script. Note that the script tag needs to be run after HTML so where you place it is important.
    BrowserDetection();
</script>

</html>

<script>
    $('form button').on("click", function (e) {
        e.preventDefault();
    });
</script>

