@extends('layouts.layadmin')

@section('content')

<div class="row">
    <h3>Admin Panel</h3>
</div>

@endsection