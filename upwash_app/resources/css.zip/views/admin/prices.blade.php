@extends('layouts.layadmin')

@section('content')

<form action="{{ route('setPrice') }}" method="post">
    @csrf
    <div class="row">
        <h1>Hinnat</h1>
    </div>

    <div class="row">
        <h3>Step 1</h3>
        <div class="button" v-on:click="show(1)">Show</div>
        <div class="price-block" v-bind:class="{active: step == 1}">
            <div class="row">
                <label for="step1_1">Ulkopesu</label><input type="text" name="step1_1" id="step1_1" value="{{ $data->step1_1 }}">
            </div>
            <div class="row">
                <label for="step1_2">Sisäpesu</label><input type="text" name="step1_2" id="step1_2" value="{{ $data->step1_2 }}">
            </div>
            <div class="row">
                <label for="step1_3">Molemmat</label><input type="text" name="step1_3" id="step1_3" value="{{ $data->step1_3 }}">
            </div>
        </div>
    </div>

    <div class="row">
        <h3>Step 3</h3>
        <div class="button" v-on:click="show(3)">Show</div>
        <div class="price-block" v-bind:class="{active: step == 3}">
            <div class="row">
                <label for="step3_1">PREMIUM</label><input type="text" name="step3_1" id="step3_1" value="{{ $data->step3_1 }}">
            </div>
            <div class="row">
                <label for="step3_2">STANDARD</label><input type="text" name="step3_2" id="step3_2" value="{{ $data->step3_2 }}">
            </div>
            <div class="row">
                <label for="step3_3">YRITYKSILLE </label><input type="text" name="step3_3" id="step3_3" value="{{ $data->step3_3 }}">
            </div>
        </div>
    </div>

    <div class="row">
        <h3>Step 4</h3>
        <div class="button" v-on:click="show(4)">Show</div>
        <div class="price-block" v-bind:class="{active: step == 4}">
            <div class="row">
                <label for="step4_1">SEDAN</label><input type="text" name="step4_1" id="step4_1" value="{{ $data->step4_1 }}">
            </div>
            <div class="row">
                <label for="step4_2">FARMARI</label><input type="text" name="step4_2" id="step4_2" value="{{ $data->step4_2 }}">
            </div>
            <div class="row">
                <label for="step4_3">PATTIAUTO (KORKEA)</label><input type="text" name="step4_3" id="step4_3" value="{{ $data->step4_3 }}">
            </div>
            <div class="row">
                <label for="step4_4">PATTIAUTO (MATALA)</label><input type="text" name="step4_4" id="step4_4" value="{{ $data->step4_4 }}">
            </div>
            <div class="row">
                <label for="step4_5">MASSTOAUTO</label><input type="text" name="step4_5" id="step4_5" value="{{ $data->step4_5 }}">
            </div>
        </div>
    </div>

    <div class="row">
        <h3>Step 5</h3>
        <div class="button" v-on:click="show(5)">Show</div>
        <div class="price-block" v-bind:class="{active: step == 5}">
            <div class="row">
                <label for="step5_1">Hyönteistenpoisto</label><input type="text" name="step5_1" id="step5_1" value="{{ $data->step5_1 }}">
            </div>
            <div class="row">
                <label for="step5_2">Karvojenpoisto </label><input type="text" name="step5_2" id="step5_2" value="{{ $data->step5_2 }}">
            </div>
            <div class="row">
                <label for="step5_3">Renkaiden vaihto 11€</label><input type="text" name="step5_3" id="step5_3" value="{{ $data->step5_3 }}">
            </div>
            <div class="row">
                <label for="step5_4">None</label><input type="text" name="step5_4" id="step5_4" value="{{ $data->step5_4 }}">
            </div>

        </div>
    </div>
    <div class="row">
        <h3>Step 6</h3>
        <div class="button" v-on:click="show(6)">Show</div>
        <div class="price-block" v-bind:class="{active: step == 6}" style="height: inherit !important;">
            <div class="row" style="margin-bottom: 20px">
                <div><label for="step6_1">Ulkopesu #1</label><input type="text" name="ulk1" id="step6_1" value="{{ $data->ulk1 }}"></div>
                <div><label for="step6_1">Ulkopesu #1 (minuutti)</label><input type="text" name="ulk1_time"  value="{{ $data->ulk1_time }}"></div>
                <div><label for="step6_2">Ulkopesu #2</label><input type="text" name="ulk2" id="step6_2" value="{{ $data->ulk2 }}"></div>
                <div><label for="step6_2">Ulkopesu #2 (minuutti)</label><input type="text" name="ulk2_time" value="{{ $data->ulk2_time }}"></div>
                <div><label for="step6_3">Ulkopesu #3</label><input type="text" name="ulk3" id="step6_3" value="{{ $data->ulk3 }}"></div>
                <div><label for="step6_3">Ulkopesu #3 (minuutti)</label><input type="text" name="ulk3_time" value="{{ $data->ulk3_time }}"></div>

                <div><label for="step6_4">Sisäpesu #1</label><input type="text" name="sis1" id="step6_4" value="{{ $data->sis1 }}"></div>
                <div><label for="step6_4">Sisäpesu #1 (minuutti)</label><input type="text" name="sis1_time" value="{{ $data->sis1_time }}"></div>
                <div><label for="step6_5">Sisäpesu #2</label><input type="text" name="sis2" id="step6_5" value="{{ $data->sis2 }}"></div>
                <div><label for="step6_5">Sisäpesu #2 (minuutti)</label><input type="text" name="sis2_time" value="{{ $data->sis2_time }}"></div>
                <div><label for="step6_6">Sisäpesu #3</label><input type="text" name="sis3" id="step6_6" value="{{ $data->sis3 }}"></div>
                <div><label for="step6_6">Sisäpesu #3 (minuutti)</label><input type="text" name="sis3_time" value="{{ $data->sis3_time }}"></div>

                <div><label for="step6_7">SISÄPESU + ULKOPESU #1</label><input type="text" name="mol1" id="step6_7" value="{{ $data->mol1 }}"></div>
                <div><label for="step6_7">SISÄPESU + ULKOPESU #1 (minuutti)</label><input type="text" name="mol1_time" value="{{ $data->mol1_time }}"></div>
                <div><label for="step6_8">SISÄPESU + ULKOPESU #2</label><input type="text" name="mol2" id="step6_8" value="{{ $data->mol2 }}"></div>
                <div><label for="step6_8">SISÄPESU + ULKOPESU #2 (minuutti)</label><input type="text" name="mol2_time" value="{{ $data->mol2_time }}"></div>
                <div><label for="step6_9">SISÄPESU + ULKOPESU #3</label><input type="text" name="mol3" id="step6_9" value="{{ $data->mol3 }}"></div>
                <div><label for="step6_9">SISÄPESU + ULKOPESU #3 (minuutti)</label><input type="text" name="mol3_time" value="{{ $data->mol3_time }}"></div>
            </div>

        </div>
    </div>

    <input type="submit" value="Save">
</form>

@endsection
