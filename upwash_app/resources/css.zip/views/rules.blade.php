<html>
<head>
    <meta content="text/html; charset=UTF-8" http-equiv="content-type">
    <style
        type="text/css">@import url('https://themes.googleusercontent.com/fonts/css?kit=fpjTOVmNbO4Lz34iLyptLSGpxL_7AiMlXksihSwXLVW_b3mVUugJgWKHJhe4sXk2Fagg4GuQvOPGHXaueYGuW_esZW2xOQ-xsNqO47m55DA');

        .lst-kix_list_4-1 > li {
            counter-increment: lst-ctn-kix_list_4-1
        }

        ol.lst-kix_list_3-1 {
            list-style-type: none
        }

        ol.lst-kix_list_3-2 {
            list-style-type: none
        }

        .lst-kix_list_3-1 > li {
            counter-increment: lst-ctn-kix_list_3-1
        }

        ol.lst-kix_list_3-3 {
            list-style-type: none
        }

        ol.lst-kix_list_3-4.start {
            counter-reset: lst-ctn-kix_list_3-4 0
        }

        ol.lst-kix_list_3-4 {
            list-style-type: none
        }

        ol.lst-kix_list_3-0 {
            list-style-type: none
        }

        .lst-kix_list_1-1 > li {
            counter-increment: lst-ctn-kix_list_1-1
        }

        .lst-kix_list_3-0 > li:before {
            content: "" counter(lst-ctn-kix_list_3-0, decimal) ". "
        }

        ol.lst-kix_list_3-1.start {
            counter-reset: lst-ctn-kix_list_3-1 0
        }

        .lst-kix_list_3-1 > li:before {
            content: "" counter(lst-ctn-kix_list_3-1, decimal) ". "
        }

        .lst-kix_list_3-2 > li:before {
            content: "" counter(lst-ctn-kix_list_3-2, decimal) ". "
        }

        ol.lst-kix_list_1-8.start {
            counter-reset: lst-ctn-kix_list_1-8 0
        }

        .lst-kix_list_4-0 > li {
            counter-increment: lst-ctn-kix_list_4-0
        }

        .lst-kix_list_3-5 > li:before {
            content: "" counter(lst-ctn-kix_list_3-5, decimal) ". "
        }

        .lst-kix_list_3-4 > li:before {
            content: "" counter(lst-ctn-kix_list_3-4, decimal) ". "
        }

        ol.lst-kix_list_1-5.start {
            counter-reset: lst-ctn-kix_list_1-5 0
        }

        .lst-kix_list_3-3 > li:before {
            content: "" counter(lst-ctn-kix_list_3-3, decimal) ". "
        }

        ol.lst-kix_list_3-5 {
            list-style-type: none
        }

        ol.lst-kix_list_3-6 {
            list-style-type: none
        }

        ol.lst-kix_list_3-7 {
            list-style-type: none
        }

        ol.lst-kix_list_3-8 {
            list-style-type: none
        }

        .lst-kix_list_3-8 > li:before {
            content: "" counter(lst-ctn-kix_list_3-8, decimal) ". "
        }

        .lst-kix_list_3-6 > li:before {
            content: "" counter(lst-ctn-kix_list_3-6, decimal) ". "
        }

        .lst-kix_list_4-3 > li {
            counter-increment: lst-ctn-kix_list_4-3
        }

        .lst-kix_list_3-7 > li:before {
            content: "" counter(lst-ctn-kix_list_3-7, decimal) ". "
        }

        ol.lst-kix_list_4-5.start {
            counter-reset: lst-ctn-kix_list_4-5 0
        }

        .lst-kix_list_1-2 > li {
            counter-increment: lst-ctn-kix_list_1-2
        }

        ol.lst-kix_list_3-7.start {
            counter-reset: lst-ctn-kix_list_3-7 0
        }

        ol.lst-kix_list_4-2.start {
            counter-reset: lst-ctn-kix_list_4-2 0
        }

        .lst-kix_list_3-2 > li {
            counter-increment: lst-ctn-kix_list_3-2
        }

        .lst-kix_list_1-4 > li {
            counter-increment: lst-ctn-kix_list_1-4
        }

        .lst-kix_list_4-4 > li {
            counter-increment: lst-ctn-kix_list_4-4
        }

        ol.lst-kix_list_1-6.start {
            counter-reset: lst-ctn-kix_list_1-6 0
        }

        .lst-kix_list_4-8 > li:before {
            content: "" counter(lst-ctn-kix_list_4-8, decimal) ". "
        }

        .lst-kix_list_4-7 > li:before {
            content: "" counter(lst-ctn-kix_list_4-7, decimal) ". "
        }

        ol.lst-kix_list_4-1.start {
            counter-reset: lst-ctn-kix_list_4-1 0
        }

        ol.lst-kix_list_4-8.start {
            counter-reset: lst-ctn-kix_list_4-8 0
        }

        ol.lst-kix_list_3-3.start {
            counter-reset: lst-ctn-kix_list_3-3 0
        }

        ol.lst-kix_list_1-0.start {
            counter-reset: lst-ctn-kix_list_1-0 4
        }

        .lst-kix_list_3-0 > li {
            counter-increment: lst-ctn-kix_list_3-0
        }

        .lst-kix_list_3-3 > li {
            counter-increment: lst-ctn-kix_list_3-3
        }

        ol.lst-kix_list_4-0.start {
            counter-reset: lst-ctn-kix_list_4-0 1
        }

        .lst-kix_list_3-6 > li {
            counter-increment: lst-ctn-kix_list_3-6
        }

        ol.lst-kix_list_3-2.start {
            counter-reset: lst-ctn-kix_list_3-2 0
        }

        ol.lst-kix_list_4-7.start {
            counter-reset: lst-ctn-kix_list_4-7 0
        }

        ol.lst-kix_list_1-3 {
            list-style-type: none
        }

        ol.lst-kix_list_1-4 {
            list-style-type: none
        }

        .lst-kix_list_2-6 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_2-7 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_3-7 > li {
            counter-increment: lst-ctn-kix_list_3-7
        }

        ol.lst-kix_list_1-5 {
            list-style-type: none
        }

        ol.lst-kix_list_1-6 {
            list-style-type: none
        }

        ol.lst-kix_list_1-0 {
            list-style-type: none
        }

        .lst-kix_list_2-4 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_2-5 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_2-8 > li:before {
            content: "\002022 "
        }

        ol.lst-kix_list_1-1 {
            list-style-type: none
        }

        ol.lst-kix_list_1-2 {
            list-style-type: none
        }

        ol.lst-kix_list_4-6.start {
            counter-reset: lst-ctn-kix_list_4-6 0
        }

        ol.lst-kix_list_3-0.start {
            counter-reset: lst-ctn-kix_list_3-0 9
        }

        ol.lst-kix_list_4-3.start {
            counter-reset: lst-ctn-kix_list_4-3 0
        }

        ol.lst-kix_list_1-7 {
            list-style-type: none
        }

        .lst-kix_list_4-7 > li {
            counter-increment: lst-ctn-kix_list_4-7
        }

        .lst-kix_list_1-7 > li {
            counter-increment: lst-ctn-kix_list_1-7
        }

        ol.lst-kix_list_1-8 {
            list-style-type: none
        }

        ol.lst-kix_list_3-8.start {
            counter-reset: lst-ctn-kix_list_3-8 0
        }

        .lst-kix_list_4-0 > li:before {
            content: "" counter(lst-ctn-kix_list_4-0, decimal) ". "
        }

        .lst-kix_list_3-8 > li {
            counter-increment: lst-ctn-kix_list_3-8
        }

        .lst-kix_list_4-1 > li:before {
            content: "" counter(lst-ctn-kix_list_4-1, decimal) ". "
        }

        .lst-kix_list_4-6 > li {
            counter-increment: lst-ctn-kix_list_4-6
        }

        ol.lst-kix_list_1-7.start {
            counter-reset: lst-ctn-kix_list_1-7 0
        }

        .lst-kix_list_4-4 > li:before {
            content: "" counter(lst-ctn-kix_list_4-4, decimal) ". "
        }

        .lst-kix_list_1-5 > li {
            counter-increment: lst-ctn-kix_list_1-5
        }

        .lst-kix_list_4-3 > li:before {
            content: "" counter(lst-ctn-kix_list_4-3, decimal) ". "
        }

        .lst-kix_list_4-5 > li:before {
            content: "" counter(lst-ctn-kix_list_4-5, decimal) ". "
        }

        .lst-kix_list_4-2 > li:before {
            content: "" counter(lst-ctn-kix_list_4-2, decimal) ". "
        }

        .lst-kix_list_4-6 > li:before {
            content: "" counter(lst-ctn-kix_list_4-6, decimal) ". "
        }

        .lst-kix_list_1-8 > li {
            counter-increment: lst-ctn-kix_list_1-8
        }

        ol.lst-kix_list_1-4.start {
            counter-reset: lst-ctn-kix_list_1-4 0
        }

        .lst-kix_list_3-5 > li {
            counter-increment: lst-ctn-kix_list_3-5
        }

        ol.lst-kix_list_1-1.start {
            counter-reset: lst-ctn-kix_list_1-1 0
        }

        ol.lst-kix_list_4-0 {
            list-style-type: none
        }

        .lst-kix_list_3-4 > li {
            counter-increment: lst-ctn-kix_list_3-4
        }

        ol.lst-kix_list_4-1 {
            list-style-type: none
        }

        ol.lst-kix_list_4-4.start {
            counter-reset: lst-ctn-kix_list_4-4 0
        }

        ol.lst-kix_list_4-2 {
            list-style-type: none
        }

        ol.lst-kix_list_4-3 {
            list-style-type: none
        }

        ol.lst-kix_list_3-6.start {
            counter-reset: lst-ctn-kix_list_3-6 0
        }

        ol.lst-kix_list_1-3.start {
            counter-reset: lst-ctn-kix_list_1-3 0
        }

        ul.lst-kix_list_2-8 {
            list-style-type: none
        }

        ol.lst-kix_list_1-2.start {
            counter-reset: lst-ctn-kix_list_1-2 0
        }

        ol.lst-kix_list_4-8 {
            list-style-type: none
        }

        ul.lst-kix_list_2-2 {
            list-style-type: none
        }

        .lst-kix_list_1-0 > li:before {
            content: "" counter(lst-ctn-kix_list_1-0, decimal) ". "
        }

        ul.lst-kix_list_2-3 {
            list-style-type: none
        }

        ul.lst-kix_list_2-0 {
            list-style-type: none
        }

        ul.lst-kix_list_2-1 {
            list-style-type: none
        }

        ol.lst-kix_list_4-4 {
            list-style-type: none
        }

        ul.lst-kix_list_2-6 {
            list-style-type: none
        }

        ol.lst-kix_list_4-5 {
            list-style-type: none
        }

        .lst-kix_list_1-1 > li:before {
            content: "" counter(lst-ctn-kix_list_1-1, decimal) ". "
        }

        .lst-kix_list_1-2 > li:before {
            content: "" counter(lst-ctn-kix_list_1-2, decimal) ". "
        }

        ul.lst-kix_list_2-7 {
            list-style-type: none
        }

        ol.lst-kix_list_4-6 {
            list-style-type: none
        }

        ul.lst-kix_list_2-4 {
            list-style-type: none
        }

        ol.lst-kix_list_4-7 {
            list-style-type: none
        }

        ul.lst-kix_list_2-5 {
            list-style-type: none
        }

        .lst-kix_list_1-3 > li:before {
            content: "" counter(lst-ctn-kix_list_1-3, decimal) ". "
        }

        .lst-kix_list_1-4 > li:before {
            content: "" counter(lst-ctn-kix_list_1-4, decimal) ". "
        }

        ol.lst-kix_list_3-5.start {
            counter-reset: lst-ctn-kix_list_3-5 0
        }

        .lst-kix_list_1-0 > li {
            counter-increment: lst-ctn-kix_list_1-0
        }

        .lst-kix_list_4-8 > li {
            counter-increment: lst-ctn-kix_list_4-8
        }

        .lst-kix_list_1-6 > li {
            counter-increment: lst-ctn-kix_list_1-6
        }

        .lst-kix_list_1-7 > li:before {
            content: "" counter(lst-ctn-kix_list_1-7, decimal) ". "
        }

        .lst-kix_list_1-3 > li {
            counter-increment: lst-ctn-kix_list_1-3
        }

        .lst-kix_list_1-5 > li:before {
            content: "" counter(lst-ctn-kix_list_1-5, decimal) ". "
        }

        .lst-kix_list_1-6 > li:before {
            content: "" counter(lst-ctn-kix_list_1-6, decimal) ". "
        }

        li.li-bullet-0:before {
            margin-left: -25pt;
            white-space: nowrap;
            display: inline-block;
            min-width: 25pt
        }

        .lst-kix_list_2-0 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_2-1 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_4-5 > li {
            counter-increment: lst-ctn-kix_list_4-5
        }

        .lst-kix_list_1-8 > li:before {
            content: "" counter(lst-ctn-kix_list_1-8, decimal) ". "
        }

        .lst-kix_list_2-2 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_2-3 > li:before {
            content: "\002022 "
        }

        .lst-kix_list_4-2 > li {
            counter-increment: lst-ctn-kix_list_4-2
        }

        ol {
            margin: 0;
            padding: 0
        }

        table td, table th {
            padding: 0
        }

        .c1 {
            background-color: #ffffff;
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 13.5pt;
            font-family: "Arial";
            font-style: normal
        }

        .c11 {
            background-color: #ffffff;
            color: #000000;
            font-weight: 700;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 12pt;
            font-family: "Times";
            font-style: normal
        }

        .c6 {
            background-color: #ffffff;
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 12pt;
            font-family: "Times";
            font-style: normal
        }

        .c3 {
            margin-left: 29pt;
            padding-top: 0pt;
            padding-left: 7pt;
            padding-bottom: 13.3pt;
            line-height: 1.0;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        .c0 {
            background-color: #ffffff;
            color: #000000;
            font-weight: 700;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 13.5pt;
            font-family: "Arial";
            font-style: normal
        }

        .c12 {
            margin-left: 36pt;
            padding-top: 0pt;
            padding-bottom: 13.3pt;
            line-height: 1.0;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        .c8 {
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 13.5pt;
            font-family: "Arial";
            font-style: normal
        }

        .c7 {
            padding-top: 0pt;
            padding-bottom: 13.3pt;
            line-height: 1.0;
            orphans: 2;
            widows: 2;
            text-align: left;
            height: 12pt
        }

        .c15 {
            color: #000000;
            font-weight: 700;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 13.5pt;
            font-family: "Arial";
            font-style: normal
        }

        .c10 {
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 11pt;
            font-family: "Helvetica Neue";
            font-style: normal
        }

        .c9 {
            padding-top: 0pt;
            padding-bottom: 0pt;
            line-height: 1.0;
            orphans: 2;
            widows: 2;
            text-align: left;
            height: 12pt
        }

        .c13 {
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 12pt;
            font-family: "Times New Roman";
            font-style: normal
        }

        .c2 {
            padding-top: 0pt;
            padding-bottom: 12pt;
            line-height: 1.0;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        .c4 {
            background-color: #ffffff;
            font-size: 13.5pt;
            font-family: "Arial";
            font-weight: 400
        }

        .c14 {
            background-color: #ffffff;
            max-width: 481.9pt;
            padding: 56.7pt 56.7pt 56.7pt 56.7pt
        }

        .c5 {
            padding: 0;
            margin: 0
        }

        .title {
            padding-top: 24pt;
            color: #000000;
            font-weight: 700;
            font-size: 36pt;
            padding-bottom: 6pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        .subtitle {
            padding-top: 18pt;
            color: #666666;
            font-size: 24pt;
            padding-bottom: 4pt;
            font-family: "Georgia";
            line-height: 1.0;
            page-break-after: avoid;
            font-style: italic;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        li {
            color: #000000;
            font-size: 12pt;
            font-family: "Times New Roman"
        }

        p {
            margin: 0;
            color: #000000;
            font-size: 12pt;
            font-family: "Times New Roman"
        }

        h1 {
            padding-top: 24pt;
            color: #000000;
            font-weight: 700;
            font-size: 24pt;
            padding-bottom: 6pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        h2 {
            padding-top: 18pt;
            color: #000000;
            font-weight: 700;
            font-size: 18pt;
            padding-bottom: 4pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        h3 {
            padding-top: 14pt;
            color: #000000;
            font-weight: 700;
            font-size: 14pt;
            padding-bottom: 4pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        h4 {
            padding-top: 12pt;
            color: #000000;
            font-weight: 700;
            font-size: 12pt;
            padding-bottom: 2pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        h5 {
            padding-top: 11pt;
            color: #000000;
            font-weight: 700;
            font-size: 11pt;
            padding-bottom: 2pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }

        h6 {
            padding-top: 10pt;
            color: #000000;
            font-weight: 700;
            font-size: 10pt;
            padding-bottom: 2pt;
            font-family: "Times New Roman";
            line-height: 1.0;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left
        }</style>
</head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-HKPWBBNHMS"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-HKPWBBNHMS');
</script>

<body class="c14 doc-content">
<div><p class="c9"><span class="c13"></span></p></div>
<p class="c2"><span class="c1">TIETOSUOJASELOSTE ASIAKAS- JA MARKKINOINTIREKISTERIST&Auml; </span></p>
<p class="c2"><span class="c0">1. Rekisterinpit&auml;j&auml; </span></p>
<p class="c2"><span class="c4">Upwash Oy</span><span class="c1">&nbsp;(</span><span class="c4">3267627-5</span><span
        class="c1">) </span><span class="c4">Halmetie 19, 00730 Helsinki, </span><span class="c1">j&auml;ljemp&auml;n&auml; &rdquo;Rekisterinpit&auml;j&auml;&rdquo;) </span>
</p>
<ol class="c5 lst-kix_list_4-0 start" start="2">
    <li class="c3 li-bullet-0"><span class="c1">Yhteyshenkil&ouml; rekisteri&auml; koskevissa asioissa <br></span><span
            class="c4">Jyri Gromyko</span><span class="c1">, </span><span class="c4">+358449782028,</span><span
            class="c1">&nbsp;</span><span class="c4">jyri@gromi.fi</span></li>
    <li class="c3 li-bullet-0"><span class="c1">Rekisterin sis&auml;lt&auml;m&auml;t tiedot <br></span></li>
</ol>
<p class="c2"><span class="c1">Asiakas- ja markkinointirekisterimme voi sis&auml;lt&auml;&auml; seuraavia rekister&ouml;ityj&auml; koskevia tietoja: nimi, osoite, s&auml;hk&ouml;postiosoite, puhelinnumero, </span><span
        class="c4">palvelutarpeet, auton tiedot</span><span class="c1">, laskutus- ja maksutietoja, markkinointilupaa- tai kieltoa koskevat tiedot, mielipidekyselyiden yhteydess&auml; syntyvi&auml; tietoja, chat- palvelun k&auml;yt&ouml;n yhteydess&auml; syntyv&auml;n vapaamuotoisen keskustelun tietoja sek&auml; viestint&auml;- ja muiden palveluiden k&auml;yt&ouml;n yhteydess&auml; saatavia tietoja.</span>
</p>
<p class="c2"><span class="c0">Ev&auml;steet </span></p>
<p class="c2"><span class="c1">Rekisterimme sis&auml;lt&auml;&auml; ev&auml;steiden avulla ker&auml;ttyj&auml; henkil&ouml;tiedoiksi katsottavia tietoja. &ldquo;Ev&auml;ste&rdquo; on yleisesti k&auml;ytetty pieni tekstitiedosto, jonka internet</span><span
        class="c4">-</span><span class="c1">selain tallentaa tietokoneellesi tai muulle p&auml;&auml;telaitteellesi, kun vierailet verkkosivulla. Selain l&auml;hett&auml;&auml; tiedon vierailustasi takaisin verkkosivulle, kun vierailet siell&auml; uudestaan. Kaikki nykyaikaiset verkkosivut k&auml;ytt&auml;v&auml;t ev&auml;steit&auml; tarjotakseen sinulle personoidumman selainkokemuksen. Kukin ev&auml;ste on erikseen asetettu kullekin p&auml;&auml;telaitteellesi ja ev&auml;steit&auml; voi lukea ainoastaan sill&auml; palvelimella, jolla ev&auml;ste on asetettu. Koska ev&auml;ste on sidottu selaimeen, eik&auml; l&auml;ht&ouml;kohtaisesti ole jaettavissa eri selainten tai laitteiden v&auml;lill&auml; (ellei jokin selain, lis&auml;osa tai muu sovellus erikseen mahdollista t&auml;t&auml;), ev&auml;steiden hallinnoimiseksi tekem&auml;t valintasi soveltuvat l&auml;ht&ouml;kohtaisesti vain kyseiseen yksitt&auml;iseen selaimeen. Ev&auml;ste ei voi ajaa ohjelmistoja, eik&auml; sit&auml; voida k&auml;ytt&auml;&auml; virusten tai muun haitallisen koodin toimittamiseen, eik&auml; vahingoittamaan p&auml;&auml;telaitettasi tai tiedostojasi. Yksitt&auml;ist&auml; k&auml;ytt&auml;j&auml;&auml; ei l&auml;ht&ouml;kohtaisesti voida tunnistaa pelk&auml;st&auml;&auml;n ev&auml;steen tai vastaavien teknologioiden k&auml;yt&ouml;n kautta. </span>
</p>
<p class="c2"><span class="c0">4. Henkil&ouml;tietojen k&auml;sittelyn tarkoitus ja oikeusperuste </span></p>
<p class="c2"><span class="c1">Asiakastietoja k&auml;sitell&auml;&auml;n Rekisterinpit&auml;j&auml;n asiakassuhteiden hallinnointiin, hoitamiseen, kehitt&auml;miseen, analysointiin ja tilastointiin, kohdennetun markkinointiviestinn&auml;n ja mielipidekyselyiden toteuttamiseen. K&auml;sittely perustuu Rekisterinpit&auml;j&auml;n ja rekister&ouml;idyn v&auml;liseen kauppasopimuksen mukaisten velvoitteiden hoitamiseen.</span>
</p>
<p class="c2"><span class="c1">K&auml;yt&auml;mme ev&auml;steit&auml; parantamaan ja personoimaan palvelun k&auml;ytt&ouml;kokemusta, ker&auml;&auml;m&auml;&auml;n tietoa palvelun k&auml;vij&auml;m&auml;&auml;rist&auml; ja suosituimmista sis&auml;ll&ouml;ist&auml; sek&auml; tunnistamaan usein sivulla vierailevat k&auml;vij&auml;t. Kun sivuillamme vieraillaan, voidaan tietoja ker&auml;t&auml; mm. k&auml;vij&auml;n k&auml;ytt&auml;m&auml;st&auml;&auml;n tietokoneesta, IP-osoitteesta, k&auml;ytetyst&auml; selaimesta ja palvelimesta.Ev&auml;steiden k&auml;ytt&ouml; perustuu rekister&ouml;idyn verkkosivulla annettavaan suostumukseen. Ev&auml;steiden k&auml;yt&ouml;st&auml; kielt&auml;ytyminen voi vaikuttaa sivustojen tekniseen toimivuuteen. </span>
</p>
<ol class="c5 lst-kix_list_1-0 start" start="5">
    <li class="c3 li-bullet-0"><span class="c0">Henkil&ouml;tietojen vastaanottajat </span><span class="c1"><br>Henkil&ouml;tietoja k&auml;sittelev&auml;t Rekisterinpit&auml;j&auml;n palveluksessa olevat kyseiseen teht&auml;v&auml;&auml;n valtuutetut henkil&ouml;t omien ty&ouml;suhteeseen tai alihankin</span><span
            class="c4">tasuhteessa </span><span class="c1">perustuvien velvollisuuksiensa t&auml;ytt&auml;miseksi. Henkil&ouml;tietoja voivat k&auml;sitell&auml; my&ouml;s ulkopuoliset palveluntarjoajat, esimerkiksi chat-palvelun tarjoajana. Rekisterinpit&auml;j&auml; on solminut kaikkien ulkopuolisten henkil&ouml;tietojen k&auml;sittelij&ouml;iden kanssa EU:n tietosuoja-asetuksen vaatimukset t&auml;ytt&auml;v&auml;n tietosuojaa koskevan sopimuksen, jolla varmistetaan muun muassa tietojen luottamuksellisuus. Tietoja voidaan luovuttaa tarvittaessa viranomaisille tuomioistuinten p&auml;&auml;t&ouml;sten ja viranomaisten lakiin perustuvien m&auml;&auml;r&auml;ysten tai pyynt&ouml;jen perusteella. <br></span>
    </li>
    <li class="c3 li-bullet-0"><span class="c0">Tietol&auml;hteet </span><span class="c1"><br>Henkil&ouml;tiedot ker&auml;t&auml;&auml;n l&auml;ht&ouml;kohtaisesti rekister&ouml;idylt&auml; itselt&auml;&auml;n esimerkiksi tilausta tehd&auml;ess&auml;, verkkosivuillamme sek&auml; muutoin suoraan asiakkaalta. Tietoja voidaan my&ouml;s ns. rikastaa ev&auml;steiden avulla henkil&ouml;n oman verkkosivustok&auml;ytt&auml;ytymisen pohjalta. <br></span>
    </li>
    <li class="c3 li-bullet-0"><span class="c0">Henkil&ouml;tietojen s&auml;ilytt&auml;misaika </span><span
            class="c1"><br>Henkil&ouml;tietojen s&auml;ilytt&auml;misaika vaihtelee k&auml;sitteytarkoituksen mukaan ja tietoja s&auml;ilytet&auml;&auml;n ainoastaan niin pitk&auml;&auml;n, kuin se on tarpeellista niihin tarkoituksiin n&auml;hden, joita varten tiedot on ker&auml;tty. <br></span>
    </li>
    <li class="c3 li-bullet-0"><span class="c0">Rekister&ouml;idyn oikeus vastustaa henkil&ouml;tietojen k&auml;sittely&auml; </span><span
            class="c1"><br>Rekister&ouml;idyll&auml; on oikeus aina vastustaa suoramarkkinointia sek&auml; siihen liittyv&auml;&auml; henkil&ouml;tietojen k&auml;sittely&auml;. Samoin k&auml;sittelyn perustuessa Rekisterinpit&auml;j&auml;n oikeutettuun etuun, rekister&ouml;idyll&auml; on oikeus vastustaa henkil&ouml;tietojen k&auml;sittely&auml; henkil&ouml;kohtaiseen erityiseen tilanteeseensa liittyv&auml;ll&auml; perusteella. <br></span>
    </li>
    <li class="c3 li-bullet-0"><span class="c0">Rekister&ouml;idyn muut oikeudet <br></span></li>
</ol>
<p class="c2"><span
        class="c1">a. Oikeus saada p&auml;&auml;sy henkil&ouml;tietoihin ja oikeus tietojen oikaisemiseen </span></p>
<p class="c2"><span class="c1">Rekister&ouml;idyll&auml; on oikeus saada maksutta j&auml;ljenn&ouml;s itse&auml;&auml;n koskevista henkil&ouml;tiedoista tai muutoin saada p&auml;&auml;sy omiin henkil&ouml;tietoihinsa. Rekister&ouml;idyll&auml; on oikeus vaatia, ett&auml; Rekisterinpit&auml;j&auml; oikaisee ilman aiheetonta viivytyst&auml; rekister&ouml;ity&auml; koskevat ep&auml;tarkat ja virheelliset henkil&ouml;tiedot.</span>
</p>
<p class="c2"><span class="c1">b. Oikeus tietojen poistamiseen </span></p>
<p class="c2"><span class="c1">Rekister&ouml;idyll&auml; on oikeus saada h&auml;nt&auml; koskevat tiedot poistetuksi rekisterist&auml;, mik&auml;li tietoja ei en&auml;&auml; tarvita alkuper&auml;isiin tarkoituksiin eik&auml; tietojen k&auml;sittelylle ole en&auml;&auml; esimerkiksi sopimuksen tai lakis&auml;&auml;teisen velvoitteen t&auml;ytt&auml;misen edellytt&auml;m&auml;&auml; perustetta. </span>
</p>
<p class="c7"><span class="c8"></span></p>
<ol class="c5 lst-kix_list_3-0 start" start="10">
    <li class="c3 li-bullet-0"><span class="c1">Tietopyynt&ouml;jen ja muiden rekister&ouml;ityjen oikeuksia koskevien pyynt&ouml;jen toteuttaminen <br>Rekister&ouml;ity voi osoittaa edell&auml; kohdissa 8 ja 9 mainittujen oikeuksien toteuttamista koskevan pyynn&ouml;n osoitteiseen Email-osoite. Rekisterinpit&auml;j&auml; voi pyyt&auml;&auml; rekister&ouml;ity&auml; tarkentamaan pyynt&ouml;&auml;&auml;n kirjallisesti ja varmentamaan rekister&ouml;idyn henkil&ouml;llisyyden ennen pyynn&ouml;n k&auml;sittelemist&auml;. Rekisterinpit&auml;j&auml; voi kielt&auml;yty&auml; pyynn&ouml;n toteuttamisesta tietosuoja-asetuksessa s&auml;&auml;detyll&auml; perusteella. <br></span>
    </li>
    <li class="c3 li-bullet-0"><span class="c0">Rekister&ouml;idyn oikeuksiin ja vapauksiin liittyv&auml;t mahdolliset riskit ja sovellettavat tietoturvamenettelyt </span><span
            class="c1"><br></span></li>
</ol>
<p class="c12"><span class="c1">Rekisterinpit&auml;j&auml; ja Rekisterinpit&auml;j&auml;n puolesta henkil&ouml;tietoja k&auml;sittelev&auml;t asiakas- ja markkinointirekisteriin liityvien j&auml;rjestelmien tarjoajat ovat sitoutuneet k&auml;sittelem&auml;&auml;n ja suojaamaan henkil&ouml;tietoja voimassa olevan lains&auml;&auml;d&auml;nn&ouml;n mukaisesti. <br></span>
</p>
<p class="c12"><span class="c1">Tietoliikenneyhteys k&auml;ytt&auml;j&auml;n selaimelta Rekisterinpit&auml;j&auml;n palvelimelle on salattu. S&auml;hk&ouml;isesti k&auml;sitelt&auml;v&auml; aineisto ker&auml;t&auml;&auml;n tietokantoihin, jotka ovat palomuurein, salasanoin ja muunlaisin teknisin keinoin suojattuja ja niiden k&auml;ytt&ouml;oikeudet on rajoitettu ainoastaan henkil&ouml;ille, joiden ty&ouml;teht&auml;vien hoitaminen edellytt&auml;&auml; j&auml;rjestelmien k&auml;ytt&ouml;&auml;. J&auml;rjestelmien k&auml;ytt&ouml; edellyt&auml;&auml; k&auml;ytt&auml;j&auml;tunnusta ja salasanaa, ja ainoastaan teht&auml;viin valtuuteilla henkil&ouml;ill&auml; on p&auml;&auml;sy k&auml;sitelt&auml;viin henkil&ouml;tietoihin. J&auml;rjestelmien auditoinnit suoritetaan s&auml;&auml;nn&ouml;llisesti tietoturvan jatkuvuuden varmistamiseksi. <br></span>
</p>
<p class="c2"><span class="c1">12. Tietojensiirto EU:n tai ETA:n ulkopuolelle </span></p>
<p class="c2"><span class="c1">Henkil&ouml;tietoja ei siirret&auml; EU</span><span class="c4">-alueen</span><span
        class="c1">&nbsp;ulkopuolelle. </span></p>
<p class="c2"><span class="c1">13. Automaattinenp&auml;&auml;t&ouml;ksenteko </span></p>
<p class="c2"><span
        class="c1">Henkil&ouml;tietoja ei k&auml;ytet&auml; automaattiseen p&auml;&auml;t&ouml;ksentekoon. </span></p>
<div><p class="c9"><span class="c13"></span></p></div>
</body>
</html>
